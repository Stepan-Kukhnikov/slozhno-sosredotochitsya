// 1. Необходимо вывести сообщение в консоль "все теги прогрузились", когда все теги будут созданы браузером

document.addEventListener('DOMContentLoaded', () => {
    console.log('все теги прогрузились')
});

// 2. Необходимо вывести сообщение в консоль "страница загрузилась", когда все ресурсы страницы будут загружены.

window.addEventListener('load', () => {
    console.log('страница загрузилась')
});


// 3. При клике на какой-либо тег на странице в консоль должно выводиться сообщение наподобие:
// - Класс "super_element" присутствует в элементе "div".
// - сообщение должно определять присутствует или отсутствует класс "super_element"
// - у элемента, а также выводить в нижнем регистре верный тег в данной строке, по
// - которому был совершен клик.
// - Необходимо использовать делегирование.

const bodyEl = document.querySelector('body')

function listener(e){
    const targetEL = e.target
    if (targetEL.classList.contains('super_element')){
        console.log(`Элемент ${targetEL.tagName} имеет класс super_element`);
    } else {
        console.log(`Элемент ${targetEL.tagName} не имеет класс super_element`);
    }
}

bodyEl.addEventListener('click', listener)

// 4. Сделайте, чтобы при наведении на textarea в консоли 
// появлялось сообщение: "Вы навели на textarea."

const textAreaEl = document.querySelector('textarea')

textAreaEl.addEventListener('mouseover', ()=>{
    console.log('Вы навели на textarea.');
})

// 5. Необходимо повесить событие клика на тег ul.
// В обработчике события в консоль необходимо выводить текст, который 
// записан внутри элемента кнопки, по которой был произведен клик. Если клик был не по кнопке,
// то ничего выводить не нужно. Необходимо использовать делегирование.

const ulEl = document.querySelector('ul')

function clickOnButton(e){
    const buttonTarget = e.target
    const isButtonEl = buttonTarget.tagName
    if (isButtonEl == 'BUTTON'){
        console.log(`${buttonTarget.textContent}`);
    }
}


ulEl.addEventListener('click',(clickOnButton))

// 6. Вопрос: Почему в console.log пишется сначала 
// текст из 5 задания и только потом выводится текст из 3 задания, если мы кликаем
// по кнопкам в ul? Ответ необходимо написать здесь же, под этим комментарием, своими словами.

// Потому что областью поиска элемента при помощи querySelector из 5 задания является элемент
// ul и находится раньше, а область поиска элемента при помощи querySelector из 3 задания
// является body и находится после окончания проверки всего документа на предмет искомого элемента 
// (наверное так)

// 7. С помощью JS необходимо изменить цвет заднего фона каждого второго тега li.

////////////////////////////////////////////////////

// uLNodeList.forEach((element) => {
//     const elemIndex = element.indexOf('liEl')
//     console.log(elemIndex);
//         element.style.backgroundColor = 'red'
//     }
// );

// const liEls = document.querySelectorAll('li')

// liEls.forEach((element) => {
//     const everySecondEl = element.indexOf('li')
//     console.log(everySecondEl);
//     console.log(element);
// })

const uLNodeList = ulEl.children
console.log(uLNodeList);

const arr = [...uLNodeList]
console.log(arr);
console.log(arr.length);
console.log(arr.indexOf('liEl'));


// arr.forEach((element)=>{
//     const everySecondEl = element.indexOf('liEl')
//     console.log(everySecondEl);
// })